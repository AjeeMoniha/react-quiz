import React from "react";
import { UserContext } from "./Filtered";

const HeaderWrong=(props)=>{
    return(
    <div>
       <UserContext.Consumer>{
        user=>{
    return <button className="logout" onClick={props.value}><span>My Wrong Attempt</span>
      <span className="badge">{user}</span></button>
        }
        }
       </UserContext.Consumer>
    </div>
    );
}

export default HeaderWrong;