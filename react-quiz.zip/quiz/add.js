import React,{useState} from "react"; 
import "./Add.css";

const Add = (props)=>{
    const [enteredQuestion, setEnteredQuestion] = useState("");   
    const [enteredOptionA, setEnteredOptionA] = useState("");   
    const [enteredOptionB, setEnteredOptionB] = useState(""); 
    const [enteredOptionC, setEnteredOptionC] = useState(""); 
    const [enteredOptionD, setEnteredOptionD] = useState(""); 
    const [enteredDropdown, setEnteredDropdown] = useState(""); 
    const [enteredCorrect, setEnteredCorrect] = useState(""); 
    const questionChangeHandler =(event)=>{
        setEnteredQuestion(event.target.value);   
    };
    const OptionAChangeHandler =(event)=>{
        setEnteredOptionA(event.target.value);   
    };
    const OptionBChangeHandler =(event)=>{
        setEnteredOptionB(event.target.value);   
    };
    const OptionCChangeHandler =(event)=>{
        setEnteredOptionC(event.target.value);   
    };
    const OptionDChangeHandler =(event)=>{
        setEnteredOptionD(event.target.value);   
    };
    const dropdownChangeHandler =(event)=>{
        setEnteredDropdown(event.target.value);   
    };
    const correctChangeHandler =(event)=>{
        setEnteredCorrect(event.target.value);   
    };
    const submitHandler=(event)=>{
        event.preventDefault();
        const newQuiz ={
            questions: enteredQuestion,  
            option1: enteredOptionA,
            option2: enteredOptionB,
            option3: enteredOptionC,
            option4: enteredOptionD,
            dropdown: enteredDropdown,
            correct: enteredCorrect,
        };
    props.onSaveQuizData(newQuiz);
    setEnteredQuestion("");
    setEnteredOptionA("");
    setEnteredOptionB("");
    setEnteredOptionC("");
    setEnteredOptionD("");
    setEnteredDropdown("");
    setEnteredCorrect("");
    };

return(
    <form onSubmit={submitHandler}>
    <div>
        <div className="question">
            <label>Enter your question</label>
            <textarea type ="text" value={enteredQuestion} onChange={questionChangeHandler} required/>
        </div> 
        <div className="questions">
        <label>Category</label> <select name="dropdown" id="dropdown" value={enteredDropdown} onChange={dropdownChangeHandler} required>
              <option value=""> Choose Category</option>
              <option value="React">React</option>
              <option value="HTML">HTML</option>
              <option value="CSS">CSS</option>
              <option value="JavaScript">JavaScript</option>
        </select></div>
        <div className="questions">
            <label>Option A</label> <input type ="text" value={enteredOptionA} onChange={OptionAChangeHandler} required/>
        </div>
        <div className="questions">
            <label>Option B</label> <input type ="text" value={enteredOptionB} onChange={OptionBChangeHandler} required/>
        </div>
        <div className="questions">
            <label>Option C</label> <input type ="text" value={enteredOptionC} onChange={OptionCChangeHandler} required/>
        </div>
        <div className="questions">
            <label>Option D</label> <input type ="text" value={enteredOptionD} onChange={OptionDChangeHandler} required/>
        </div>
        <div className="questions">
        <label>Correct</label> <input type ="text" id="correct" value={enteredCorrect} onChange={correctChangeHandler} required/>
              </div>
        <div>
            <button className="new_button" onClick={props.onCancel}>CANCEL</button>
            <button className="submit" type ="submit">ADD</button>
        </div>
    </div>
</form>
);
};


export default Add;