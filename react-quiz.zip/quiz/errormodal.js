import React from "react";
import "./Errormodal.css";

const Errormodal = (props)=>{
  
    return(
        <div className="backdrop" onClick={props.onConfirm}>
        <div className="error">
            <div className="top">{props.title}</div>
            <div className="middle">{props.message}</div>
            <button className="ok" onClick={props.onConfirm}>Ok</button>
        </div></div>
    );
}

export default Errormodal;