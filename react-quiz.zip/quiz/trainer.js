import React, { useState } from "react";
import Add from './Add';
import Filter from './Filter';
import Filtered from './Filtered';
import Header from "./Header";

const initial_Ques = [{
  id: 1,
  questions: "React is mainly for building _______ ?",
  option1: "Database",
  option2: "Connectivity",
  option3: "User interface",
  option4: "Design Platform",
  dropdown: "React",
  correct: "User interface",
},
{
  id: 2,
  questions: "HTML can be rendered and read by?",
  option1: "Web Browser",
  option2: "Server",
  option3: "Controller",
  option4: "Router",
  dropdown: "HTML",
  correct: "Web Browser",
},
{
  id: 3,
  questions: "Props are _______ into other components ?",
  option1: "Injected",
  option2: "Method",
  option3: "Both A and B",
  option4: "None of these",
  dropdown: "React",
  correct: "Injected",
},
{
  id: 4,
  questions: "< br  / > What type of tag is this?",
  option1: "A Broken One",
  option2: "Break tag",
  option3: "An opening tag",
  option4: "An closing tag",
  dropdown: "HTML",
  correct: "Break tag",
},
{
  id: 5,
  questions: " What does HTML stand for?",
  option1: "Hot Mail",
  option2: "How to Make Lasagna",
  option3: "Hyper Text Markup Language",
  option4: "None of these",
  dropdown: "HTML",
  correct: "Hyper Text Markup Language",
},
{
  id: 7,
  questions: "Which one of the following is an ternary operator?",
  option1: "?",
  option2: ":",
  option3: "-",
  option4: "+",
  dropdown: "JavaScript",
  correct: "?",
},
{
  id: 6,
  questions: "What are the three important manipulations for a loop on a loop variable?",
  option1: "Updation, Incrementation, Initialization",
  option2: "Initialization, Testing, Incrementation",
  option3: "Testing, Updation, Testing",
  option4: "Initialization, Testing, Updation",
  dropdown: "JavaScript",
  correct: "Initialization, Testing, Updation",
},];

function Trainer(props) {
  
  const [Ques, setQuiz] = useState(initial_Ques);
  
  const addQuizHandler = (Quiz) => {
    setQuiz((prevQuiz) => {
      return [Quiz, ...prevQuiz];
    });
  };
  const [filteredDropdown, setFilteredDropdown] = useState("HTML");
  const filterChangeHandler = (selectedDropdown) => {
    setFilteredDropdown(selectedDropdown);
  };
  const filteredDrop = Ques.filter((quiz) => {
    return quiz.dropdown === filteredDropdown;
  });
  const[isEditable, setIsEditable]=useState(false);
  const saveQuizDataHandler = (enteredQuiz) => {
    const quizData = {
      ...enteredQuiz,
      id: Math.random().toString(),
    };
    //console.log(quizData);
    addQuizHandler(quizData);
    setIsEditable(false);
     };
     const startEditingHandler =()=>{
      setIsEditable(true);
 };
 const stopEditingHandler =()=>{
     setIsEditable(false);
 };
  const train = props.email;
  const logout = props.onLogout;
  const disable=props.disable;
  const role =props.role;
  return (
    <div>    
      <Header train={train} logout={logout} role={role}/>
      {disable=== true ? (<div className="add">
        <div className="covr">
        {!isEditable && (
        <button className="new" onClick={startEditingHandler}>ADD NEW QUESTION</button>
    )}
       {isEditable && (
       <Add
       onSaveQuizData={saveQuizDataHandler}
       onCancel={stopEditingHandler}
       /> 
       )}     
        </div></div>):""}
        

      <div className="template">
        
        <Filter selected={filteredDropdown} onFilterChange={filterChangeHandler} />
        <Filtered dropdown={filteredDrop} />
      </div></div>
  );
};

export default Trainer;
