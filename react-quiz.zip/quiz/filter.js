import "./Filter.css";
const Filter = (props)=>{
    const dropdownChangeHandler =(event)=>{
      props.onFilterChange(event.target.value);
    };
   
    return(
        <div className="filter">
          <div className="filter__control">
           <label>Filter by Category</label>
           <select value={props.selected} onChange={dropdownChangeHandler}>
            <option value ="React" >React </option>
            <option value ="HTML">HTML</option>
            <option value ="CSS">CSS</option>
            <option value ="JavaScript">JavaScript</option>
           </select>
          </div>
        </div>
    );
};

export default Filter;