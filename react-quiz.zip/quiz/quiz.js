import React from "react";
import "./Quiz.css";

const Quiz = (props) => {
  const { Ques } = props;

  const [counter, setCounter] = React.useState(props.Ques * 20);
  React.useEffect(() => {
    const timer =
      counter > 0 && setInterval(() =>
        setCounter(counter - 1), 1000);
    return () =>
      clearInterval(timer);
  });

  return (

    <div className="wrapper">
      <div className="column-left">Total Questions : {Ques}</div>
      <div className="column-right">Time Left : <span id="count">{counter}</span> sec</div>
    </div>

  );
};

export default Quiz;