import React,{useState} from "react";
import ReportModal from "./ReportModal";
import Questions from './Questions';
import Quiz from './Quiz';
import HeaderWrong from "./HeaderWrong";

export const UserContext=React.createContext()

const Filtered=(props) =>{
  var wrng=[];
  const [error1, setError1] = useState();
  const [submit1, setsubmit1] = useState();
  const [Wrong, setQuiz] = useState(wrng);
    const addQuizHandler = (Data) => {
       setQuiz((prevdata) => {
         return [...prevdata,Data];
       });
      };
      const saveFormDataHandler = (data) => {
        const Data = {
          ...data,
        };
        addQuizHandler(Data);
        
      };
  var count = 0;
    if(props.dropdown.length === 0){
      return<h2 className="found">No Quiz Found</h2>;
  }

  const submit =()=>{
      if(Wrong.length === 0){
      alert();
      setsubmit1({
        message: "Here's Your Report.",
      });
    }
    else{
      setsubmit1({
        message: "Here's Your Report.",
      });
    }
    
  };

const alert =()=>{
  setError1({
    message: "Here's Your Report.",
  });
};
const errorHandler = () => {
    setError1(null);
  };


  return(
    <div> 
        <Quiz Ques={props.dropdown.length}/>
          {props.dropdown.map((quiz)=>{
            count = count+1;
            return<Questions formdata={saveFormDataHandler} key={quiz.id} quiz={quiz} count={count} Ques={props.dropdown.length} />;
          })
          }
          
         {<button className="submit" onClick={submit}>SUBMIT</button> }
         <UserContext.Provider value={Wrong.length} >
         {submit1 &&<HeaderWrong value={alert}/>}
         {error1 && <ReportModal onConfirm={errorHandler} count={Wrong.length} wrong={Wrong} message={error1.message}/>}
         </UserContext.Provider>
      </div>
  );  
};
  export default Filtered;