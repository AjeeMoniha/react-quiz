import React, { useState, useRef } from "react";
import Errormodal from "./Errormodal";
import './Login.css';

const Login = (props) => {
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState();
  const [title, settitle] = useState();
  var heading;
  var errorMessage;
  const emailInputRef = useRef();
  const passwordInputRef = useRef();

  const switchAuthModeHandler = () => {
    setIsLogin((prevState) => !prevState);
  };

  const submitHandler = (event) => {
    event.preventDefault();
    const enteredEmail = emailInputRef.current.value;
    const enteredPassword = passwordInputRef.current.value;
    console.log(enteredEmail);
    console.log(enteredPassword);
    localStorage.setItem("enteredEmail", enteredEmail);
    localStorage.setItem("enteredPassword", enteredPassword);

    setIsLoading(true);
    let url;
    if (isLogin) {
      //logic for login
      url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyAjhlLKSN9mgM9M9UKDQ7OpafIcb0W2Ecw";
     fetch(url,
      {
        method: "POST",
        body: JSON.stringify({
          email: enteredEmail,
          password: enteredPassword,
          returnSecureToken: true,
        }),
        headers: { "content-Type": "application/json" },
      }
    ).then((res) => {
      setIsLoading(false);
      if (res.ok) {
        //show the success message
        props.onLogin();
        return res.json();
      } else {
        //show error message
        return res.json().then((data) => {
          errorMessage = "Autentication Failed";
          if (data && data.error && data.error.message) {
            heading="REPORT ERROR ❗️❗️❗️"
            settitle(heading);
            errorMessage = data.error.message;
            setError(errorMessage);
          }

        });

      }
    })
    }
    else {
      //logic for signup
      url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyAjhlLKSN9mgM9M9UKDQ7OpafIcb0W2Ecw";
      fetch(url,
        {
          method: "POST",
          body: JSON.stringify({
            email: enteredEmail,
            password: enteredPassword,
            returnSecureToken: true,
          }),
          headers: { "content-Type": "application/json" },
        }
      ).then((res) => {
        setIsLoading(false);
        if (res.ok) {
          //show the success message
          heading="SUCCESS 💯"
          settitle(heading);
          errorMessage = "Data Saved Successfully";
          setError(errorMessage);
          return res.json();
        } else {
          //show error message
          return res.json().then((data) => {
            errorMessage = "Autentication Failed";
            if (data && data.error && data.error.message) {
              errorMessage = data.error.message;
              heading="REPORT ERROR ❗️❗️❗️"
              settitle(heading);
              setError(errorMessage);
            }
  
          });
  
        }
      })
    }
  }
    const errorHandler = () => {
      setError(null);
    }

    return (
      <div>
        {error && title && <Errormodal message={error} title={title} onConfirm={errorHandler} />}
        <div><h1>👩‍💻</h1>
          <h2>{isLogin ? 'Login To Your Account' : 'Sign up To Login'}  </h2>
          <div className="login">
            <form onSubmit={submitHandler}>
              <label>Username or Email Address</label> <br></br>
              <input type="email" ref={emailInputRef} required /><br></br>
              <label>Enter Password</label> <br></br>
              <input type="password" ref={passwordInputRef} required /><br></br>
              {!isLoading && <button type="submit" id="Submit">{isLogin ? "Login" : "Sign Up"}</button>}
              {isLoading && <p>Loading...</p>}
              <p onClick={switchAuthModeHandler}>
                {isLogin ? 'Create new account' : 'Login with existing account'}</p>
            </form>

          </div></div>
      </div>
    );
  };
  export default Login;