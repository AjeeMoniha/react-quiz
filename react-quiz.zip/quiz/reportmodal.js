import React,{useState} from "react";
import "./Errormodal.css";
import "./ReportModal.css";

const ReportModal = (props) => {
   var disable;
    
   var array = props.wrong;
   const [wrong, setWrong] = useState(array);
   
    var id = 0;
    var del;
    if (array.length === 0) {
        disable = true;
    }
 // delete button
    const delt = (e) => {
    e.preventDefault();
    del = e.target.value-1;
    console.log(del);
   const newarray = (array ||[]).splice(del, 1);
    setWrong(newarray);
    }  

  //clear button
   const pop =()=>{
           const newarr= (array ||[]).splice(0,array?.length);  
             console.log(wrong);  
           setWrong(newarr);            
    }
      
    return (
        <div className="backdrop">
            <div className="report">
                <div className="top">🔍 ANALYSIS 🕵 REPORT 🔎</div>
                <div className="you"></div>
                {!disable === true &&
                    <button className="logout"><span>My Wrong Attempt</span>
                        <span className="badge">{array.length}</span></button>}

                {array.map((quiz) => {
                    id = id + 1;
                    return (
                        <div className="container" key={id}>
                            <button className="del" value={id} onClick={delt}>🗑️</button>
                            <div className="questions">{id}. {quiz.questions}</div>
                            <div><button className="opt1">{quiz.option1}</button></div>
                            <div><button className="opt2">{quiz.option2}</button></div>
                        </div>)

                })}
                {!disable === true && <button className="exit" onClick={pop}>CLEAR</button>}
                {disable === true &&

                    <div className="green">Congratulations 🎊<br></br> Your Attempts are Right ✅ <br></br> Good to Go 🏃‍♀️</div>
                }
                <button className="exit" onClick={props.onConfirm}>EXIT</button>
            </div></div>
    );
}
export default ReportModal;