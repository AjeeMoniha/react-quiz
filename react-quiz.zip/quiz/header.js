import React from "react";
import "./Header.css";
//import HeaderWrong from "./HeaderWrong";
//import ReportModal from "./ReportModal";

const Header= (props) =>{
    const mailid=props.train;
    const logout= props.logout;
    const role= props.role;
  
   return(
    
        <div className="Header">   
        <div className="hcl"><img src="./hcl.png" alt="logo" width="150"/></div>
        <div className="center"><span>💫</span> QUIZ🖋ZONE <span>💫</span></div>
        <div className="right"><span>🤵</span> {mailid}({role})<button className="logout" onClick={logout}>Logout</button>
        </div>
        </div>
    
   );
};

export default Header;