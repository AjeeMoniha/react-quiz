import React from "react";
import "./Questions.css";

const Questions = (props)=>{
    
    var score=0;
    var questions;
    var {count} = props;
    const {quiz} =props;
    const {Ques} =props; //total no.of.questions
    
   const option = (e)=>{
    e.preventDefault();
    e.target.classList.add("but");
    
    if(e.target.innerText !== quiz.correct){
      const data={
       score : score + 1,
       questions: quiz.questions,
       option1:e.target.innerText,
       option2:quiz.correct,
      };
       props.formdata(data); 
    };
        
   };
   
    return(
        <div>
        <div className ="cover">
        <div className = "questions">{count}. {quiz.questions}</div>
        <div><button className="one" onClick={option}>{quiz.option1}</button></div>
        <div><button className="two" onClick={option}>{quiz.option2} </button></div>
        <div><button className="three" onClick={option}>{quiz.option3}</button></div>
        <div><button className="four" onClick={option}>{quiz.option4} </button></div>
        <div className ="number">Questions {count} of {Ques}</div>
        </div>{questions}
        <div className="line"></div>
        </div>
    );
};

export default Questions;
