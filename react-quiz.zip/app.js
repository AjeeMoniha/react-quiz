import React,{useState,useEffect} from 'react';
import './App.css';
import Trainer from "./quiz/Trainer";
import Login from "./quiz/Login";
import {Routes, Route } from 'react-router-dom';
import {useNavigate} from 'react-router-dom';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false); //trainer
  const[traineelogin, settraineelogin] = useState(false); //trainee
  const nav = useNavigate()

  useEffect(()=>{
    const loggedInUserStatus=localStorage.getItem("IsLogedIn");
    const loggedInTraineerStatus=localStorage.getItem("traineelogin");
    if(loggedInUserStatus === "1"){
      setIsLoggedIn(true);
    }
    if(loggedInTraineerStatus === "1"){
      settraineelogin(true);
    }
  },[]);  
  
  const loginHandler = () => {
    const emails = localStorage.getItem("enteredEmail");
    const passwords = localStorage.getItem("enteredPassword");
    const pass = JSON.parse(passwords); // convert string to numbers
    if(emails === "pankaj@gmail.com" && pass === 1234567)
      {
       setIsLoggedIn(true);
       nav('./trainer');
       localStorage.setItem('IsLogedIn','1');
      }
      else
      {
        settraineelogin(true);
        nav('./trainee');
        localStorage.setItem('traineelogin','1');
      }
  }

  const logoutHandler = () => {
    nav(-1)
  setIsLoggedIn(false);
  settraineelogin(false); 
  localStorage.removeItem('IsLogedIn');
  localStorage.removeItem('traineelogin');
}
  return (
    <div>
    <Routes>
    <Route path='/' element={!isLoggedIn && !traineelogin && <Login onLogin={loginHandler}/>}/>
    <Route path='/trainer' element={ isLoggedIn && <Trainer disable={true} onLogout={logoutHandler} email={localStorage.getItem("enteredEmail")} role="Trainer"/>}></Route>
    <Route path='/trainee' element={traineelogin && <Trainer disable={false} onLogout={logoutHandler} email={localStorage.getItem("enteredEmail")} role="Trainee"/>}></Route>
    </Routes>
    </div>
      
  );
};

export default App;
